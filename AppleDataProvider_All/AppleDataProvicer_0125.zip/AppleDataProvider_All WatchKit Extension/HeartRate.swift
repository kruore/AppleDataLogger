//
//  HeartRate.swift
//  AppleDataProvider_All WatchKit Extension
//
//  Created by SangBin Jeon on 2021/12/22.
//

import Foundation


struct HeartRate {

    let timestamp: Date
    let bpm: Double
    
}
